from django.apps import AppConfig


class SolsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Sols'
